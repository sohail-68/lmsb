import React from 'react'

const UserCourses = () => {
  return (
    <div>UserCourses</div>
  )
}

export default UserCourses